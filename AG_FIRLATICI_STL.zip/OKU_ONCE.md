# AĞ FIRLATICI — BASKI DOSYALARI (son tasarım)

Konfigürasyon: ağ Ø2.2 m · göz 220 mm · 6 × Ø9 boncuk · yuva eğimi 40° · 2 bant

| Dosya | Parça | Adet | Filament | Yükseklik |
|---|---|---|---|---|
| 01a_namlu_govde | Namlu gövdesi (arka) | 1 | PETG | 142.0 mm |
| 01b_agiz_basligi | Ağız başlığı — koni 40° + bant ankrajı | 1 | PETG | 20.6 mm |
| 02_kapsul | Kapsül — 6 yuva 40° | 1 | PETG | 45.0 mm |
| 03_tetik_kapagi_sag | Tetik kartuş kapağı | 1 | PETG | 3.0 mm |
| 04_tetik_kapagi_sol | Tetik kartuş kapağı | 1 | PETG | 3.0 mm |
| 05_servo_makarasi | Servo ip makarası | **2** | PETG | 6.4 mm |
| 06_toz_kapagi | Arka toz kapağı (opsiyonel) | 1 | PETG | 6.0 mm |
| 07_tampon_ust | Yarık sonu tamponu | 1 | **TPU 95A** | 3.0 mm |
| 08_tampon_alt | Yarık sonu tamponu | 1 | **TPU 95A** | 3.0 mm |

**TOPLAM: PETG ~200 g · TPU ~0.2 g.** Yazıcıda Z ≥ 147 mm gerekli.

## BASMADAN ÖNCE OKU
`BASKI_AYARLARI.md` — özellikle **§1.5 DESTEK**. İlk baskıda namlu deliği
destekle doldu; o bölüm düzeltilmiş hali.

## 09_capraz_pim_TORNA — BASILMAZ
Bu parça **Ø8 alüminyum milden tornalanır**, 3D baskı DEĞİL.
STL sadece ölçü/görsel için; tornacıya `.step` dosyasını ver.
100 mm boy, z = ±36'da 14 mm genişlik × 1 mm derinlik bant oluğu.

## 3D BASKI OLMAYAN PARÇALAR
Ø5 × 30 mm çelik pim ×2 (bant taşıyıcı), Ø4 × 25 mm çelik pim ×2 (bant kilidi),
Ø5 tetik pimi ×2, PTFE burç ×2, servo ×2, lateks bant 260 mm,
Dyneema 0.60 mm ~47 m, Ø9 kurşun boncuk ×6.
Tam liste: depo kökündeki `malzeme_listesi.md`.
